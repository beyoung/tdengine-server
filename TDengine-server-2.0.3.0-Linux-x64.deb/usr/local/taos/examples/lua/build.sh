gcc lua_connector.c -fPIC -shared -o luaconnector.so -Wall -ltaos

