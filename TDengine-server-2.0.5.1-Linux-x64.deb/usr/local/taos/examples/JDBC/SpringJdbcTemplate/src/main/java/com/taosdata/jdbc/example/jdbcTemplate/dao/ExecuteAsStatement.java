package com.taosdata.jdbc.example.jdbcTemplate.dao;

public interface ExecuteAsStatement{

    void doExecute(String sql);
}
