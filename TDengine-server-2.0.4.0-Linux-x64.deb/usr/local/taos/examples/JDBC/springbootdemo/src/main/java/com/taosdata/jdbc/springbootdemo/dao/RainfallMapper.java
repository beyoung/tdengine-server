package com.taosdata.jdbc.springbootdemo.dao;

import java.util.Map;

public interface RainfallMapper {


    int save(Map<String, Object> map);
}
